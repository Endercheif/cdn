
int
float
str
bytes
list
tuple
set
