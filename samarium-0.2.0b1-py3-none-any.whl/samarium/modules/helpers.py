import sys
import typing as _typing
import samarium.objects as _obj
import functools as _functools
import importlib as _importlib


def py(item: _obj.Class):
    """Attempt to convert a Samarium object to Python"""
    if isinstance(item, _obj.Array):
        return [*map(py, item.value)]
    elif isinstance(item, (_obj.Integer, _obj.String)):
        return item.value
    elif isinstance(item, _obj.Table):
        return {py(k): py(v) for k, v in item.value.items()}
    return item


def sm(item):
    """Convert a Python object to a Samarium object"""
    if isinstance(item, (tuple, list, set)):
        return _obj.Array((sm(i) for i in item))
    elif isinstance(item, (int, float)):
        return _obj.Int[int(item)]
    elif isinstance(item, dict):
        return _obj.Table({sm(k): sm(v) for k, v in item.items()})
    elif item is None:
        return _obj.null
    return _obj.String(str(item))


def wrap(ret_sm: bool = False) -> _typing.Callable[[_typing.Callable], _typing.Any]:
    """
    Allow a Python function to take Samarium types.

    ## Example

    In ``maths.py``
    ```py
    from samarium.modules import helpers

    @helpers.wrap()
    def sqrt(a: int, b: int):
        return a ** b

    @helpers.wrap(True)
    def pythagorean(a: int, b: int) -> int:
        return int(sqrt(a**2 + b**2))
    ```


    In ``main.sm``
    ```samarium
    => * {
        <-maths;
        maths.pythagorean(//, /\\)!;
    }
    ```
    """

    def _decorator(func: _typing.Callable):
        @_functools.wraps(func)
        def wrapper(*args):
            args = [py(arg) for arg in args]
            # print(args)
            if ret_sm is True:
                return sm(func(*args))
            return func(*args)

        return wrapper

    return _decorator


def get(obj, *prop):
    """
    Allows ease of access to properties in Samarium.
    For use in Samarium with Python modules that include ``_``.

    Example
    -------

    .. code-block:: samarium

        => * {
            <-sys; == Python ``sys`` module

            == same as ``sys.version_info.major`` in Python
            version: get(sys, "version_info", "major"); == 3

        }
    """
    item = obj
    for p in prop:
        item = _get(item, str(p))

    return item


def _get(obj, prop: str):
    if isinstance(obj, _obj.Module):
        return getattr(obj, f"_{prop}_")
    return getattr(obj, prop)


@wrap()
def _import(name: str) -> _obj.Module:
    """
    Wrapper around importlib.import_module to be used in Samarium files to import python packages.
    
    Created to fix naming conflicts by only importing from Python.

    ## Example
    ```samarium
    math: import("math");   == import math from the Python standard library instead of Samarium
    math.sin(math.pi)!;     == `0`
    ```
    """
    module = _importlib.import_module(name)

    return _obj.Module(
        name,
        {
            f"_{k}_": wrap(True)(v) if callable(v) else v
            for k, v in vars(module).items()
            if not k.startswith("_")
        },
    )


globals().update({"import": _import})
