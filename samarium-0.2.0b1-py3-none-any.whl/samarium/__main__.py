from . import main, main_debug

if __name__ == "__main__":
    main()
