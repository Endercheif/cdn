class Runtime:
    import_level = 0
    quit_on_error = True
